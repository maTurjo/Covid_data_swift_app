//
//  Todo.swift
//  Lab_7
//
//  Created by user202461 on 4/8/22.
//

import Foundation

struct Question{
    let title:String
    let isComplete:Bool = false
}
