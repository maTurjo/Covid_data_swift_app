//
//  TableViewCellWithDelete.swift
//  Lab_7
//
//  Created by user202461 on 4/8/22.
//

import UIKit

class TableViewCellWithDelete: UITableViewCell {


    @IBOutlet weak var Title: UILabel!
    
   

    
    
}
